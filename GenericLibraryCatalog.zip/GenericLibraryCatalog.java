public class GenericLibraryCatalog {
    public static void main(String[] args) {
        LibraryCatalogUI.start();
    }
}
